local REQUIRED_MODULE = require(script.Parent._Index["nightcycle_signal@1.0.2"]["signal"])
export type Signal = REQUIRED_MODULE.Signal 
export type SignalConnection = REQUIRED_MODULE.SignalConnection 
return REQUIRED_MODULE
