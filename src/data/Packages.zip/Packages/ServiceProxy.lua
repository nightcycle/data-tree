return require(script.Parent._Index["nightcycle_service-proxy@1.0.0"]["service-proxy"])
